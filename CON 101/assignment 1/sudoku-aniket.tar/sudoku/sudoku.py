# Sudoku Game for Google App Engine
# Last updated: 
# Author: quantumcoder 

import cgi
import os
import urllib2
import re
import logging
import json
import ast
from random import random
import numpy as np

from google.appengine.api import *
from google.appengine.ext.webapp import template
from google.appengine.ext.webapp.util import run_wsgi_app

import jinja2
import webapp2

JINJA_ENVIRONMENT = jinja2.Environment(
    loader=jinja2.FileSystemLoader(os.path.dirname(__file__)),
    extensions=['jinja2.ext.autoescape'],
    autoescape=True) 


class SudokuGenerator():

	def rowTransform(self,l1,l2):
		m = int(random()*3);
		n = int(random()*3);
		p = int(random()*3);
		l1[3*p+m], l1[3*p+n] = l1[3*p+n], l1[3*p+m] ;
		l2[3*p+m], l2[3*p+n] = l2[3*p+n], l2[3*p+m] ;
		return (l1,l2) ;


	def columnTransform(self,l1,l2):
		m = int(random()*3);
		n = int(random()*3);
		p = int(random()*3);
		for i in range(9):
			l1[i][3*p+m], l1[i][3*p+n] = l1[i][3*p+n], l1[i][3*p+m] ;
		for i in range(9):
			l2[i][3*p+m], l2[i][3*p+n] = l2[i][3*p+n], l2[i][3*p+m] ;
		return (l1,l2);


	def rotate(self,l1,l2):
		a1 = np.array(l1)
		a1 = np.rot90(a1);
		a2 = np.array(l2)
		a2 = np.rot90(a2);

		return (a1.tolist(),a2.tolist()) ;

	def mirrory(self,l1,l2):
		a1 = np.array(l1)
		a1 = np.fliplr(a1);
		a2 = np.array(l2)
		a2 = np.fliplr(a2);
		return (a1.tolist(),a2.tolist()) ;

	def mirrorx(self,l1,l2):
		a1 = np.array(l1)
		a1 = np.flipud(a1);
		a2 = np.array(l2)
		a2 = np.flipud(a2);
		return (a1.tolist(),a2.tolist()) ;

	def diagonalTransform(self,l1,l2):
		a1 = np.array(l1)
		a1 = np.transpose(a1);
		a2 = np.array(l2)
		a2 = np.transpose(a2);
		return (a1.tolist(),a2.tolist()) ;

	def randomize(self,grid1,grid2,n):
		for i in range(n):
			r = int(random()*6);
			
			if(r == 0):
				(grid1,grid2) = self.rowTransform(grid1,grid2);
				
			elif (r == 1):
				(grid1,grid2) = self.columnTransform(grid1,grid2);

			elif (r == 2):
				(grid1,grid2) = self.rotate(grid1,grid2);

			elif (r == 3):
				(grid1,grid2) = self.mirrorx(grid1,grid2);

			elif (r == 4):
				(grid1,grid2) = self.mirrory(grid1,grid2);

			elif (r == 5):
				(grid1,grid2) = self.diagonalTransform(grid1,grid2);
			
			else :
				pass ;
				

		return (grid1,grid2);


class EasyPage(webapp2.RequestHandler,SudokuGenerator):

	
	tablecontents = '' ;
	easylist = []; easysoln = [];
	n=1;	
	genclass = SudokuGenerator();

	def get(self,task=None):
		task = self.request.get('task')
		self.response.headers['Content-Type'] = 'html'
		EasyPage.n = int(random()*3) +1;
							
		if(task != 'viewsoln'):

			puzfilename = 'easypuz'+str(EasyPage.n)+'.txt';
			with open(puzfilename, 'r') as content_file1:
				content1 = content_file1.read();
			EasyPage.easylist = ast.literal_eval(content1);
			solnfilename = 'easysoln'+str(EasyPage.n)+'.txt';
			with open(solnfilename, 'r') as content_file2:
				content2 = content_file2.read();
			EasyPage.easysoln = ast.literal_eval(content2);
			
			(EasyPage.easylist,EasyPage.easysoln) = EasyPage.genclass.randomize(EasyPage.easylist,EasyPage.easysoln,23)

			self.tablecontents = '' ;
			
			self.list2table(EasyPage.easylist)
			template_values = {
				'tablecontents' : self.tablecontents ,
				
		    }
		
		else:
			self.tablecontents = '' ;		
			
			self.list2table(EasyPage.easysoln)
			template_values = {
				'tablecontents' : self.tablecontents ,
				
		    }

		template = JINJA_ENVIRONMENT.get_template('page.html')
		self.response.write(template.render(template_values))

	def post(self):
		self.response.headers = {'Content-Type': 'application/json; charset=utf-8'}
		self.response.out.write(json.dumps(EasyPage.easysoln))


	#add number as a readonly entry to row
	def addr_entry(self,classname,name,value):
		self.tablecontents += ("<td class='"+classname+"' ><input class='s0' size='2' autocomplete='off'  readonly='' value='"+value+"' name='"+name+"' ></td>")
		return;

	#add blank editable entry to row
	def adde_entry(self,classname,name):
		self.tablecontents += ("<td class='"+classname+"' ><input class='d0' size='2' autocomplete='off'  maxlength='1' min='1' max='9' name='"+name+"' ></td>")
		return;

	#convert 9x9 list to html content for sudoku table
	def list2table(self,list):
		for i in range(9):
			self.tablecontents += "<tr>"
			for j in range(9):
				name = "f" + str(i) + str(j)
				if(i%3 == 0):
					if(j%3 == 0):
						if(list[i][j] == ''):
							self.adde_entry('g0',name)
						else :
							self.addr_entry('g0',name,list[i][j])
					else :
						if(list[i][j] == ''):
							self.adde_entry('f0',name)
						else :
							self.addr_entry('f0',name,list[i][j])
				elif(i==8) :
					if(j%3 == 0):
						if(list[i][j] == ''):
							self.adde_entry('i0',name)
						else :
							self.addr_entry('i0',name,list[i][j])
					else :
						if(list[i][j] == ''):
							self.adde_entry('h0',name)
						else :
							self.addr_entry('h0',name,list[i][j])
				else :
					if(j%3 == 0):
						if(list[i][j] == ''):
							self.adde_entry('e0',name)
						else :
							self.addr_entry('e0',name,list[i][j])
					else :
						if(list[i][j] == ''):
							self.adde_entry('c0',name)
						else :
							self.addr_entry('c0',name,list[i][j])
			self.tablecontents += "</tr>"
		return;

class MediumPage(webapp2.RequestHandler,SudokuGenerator):

	
	tablecontents = '' ;
	mediumlist = []; mediumsoln = [];
	n=1;	
	genclass = SudokuGenerator();

	def get(self,task=None):
		task = self.request.get('task')
		self.response.headers['Content-Type'] = 'html'
		MediumPage.n = int(random()*3) +1;
							
		if(task != 'viewsoln'):

			puzfilename = 'mediumpuz'+str(MediumPage.n)+'.txt';
			with open(puzfilename, 'r') as content_file1:
				content1 = content_file1.read();
			MediumPage.mediumlist = ast.literal_eval(content1);
			solnfilename = 'mediumsoln'+str(MediumPage.n)+'.txt';
			with open(solnfilename, 'r') as content_file2:
				content2 = content_file2.read();
			MediumPage.mediumsoln = ast.literal_eval(content2);
			
			(MediumPage.mediumlist,MediumPage.mediumsoln) = MediumPage.genclass.randomize(MediumPage.mediumlist,MediumPage.mediumsoln,23)

			self.tablecontents = '' ;
			
			self.list2table(MediumPage.mediumlist)
			template_values = {
				'tablecontents' : self.tablecontents ,
				
		    }
		
		else:
			self.tablecontents = '' ;		
			
			self.list2table(MediumPage.mediumsoln)
			template_values = {
				'tablecontents' : self.tablecontents ,
				
		    }

		template = JINJA_ENVIRONMENT.get_template('page.html')
		self.response.write(template.render(template_values))

	def post(self):
		self.response.headers = {'Content-Type': 'application/json; charset=utf-8'}
		self.response.out.write(json.dumps(MediumPage.mediumsoln))


	#add number as a readonly entry to row
	def addr_entry(self,classname,name,value):
		self.tablecontents += ("<td class='"+classname+"' ><input class='s0' size='2' autocomplete='off'  readonly='' value='"+value+"' name='"+name+"' ></td>")
		return;

	#add blank editable entry to row
	def adde_entry(self,classname,name):
		self.tablecontents += ("<td class='"+classname+"' ><input class='d0' size='2' autocomplete='off'  maxlength='1' name='"+name+"' ></td>")
		return;

	#convert 9x9 list to html content for sudoku table
	def list2table(self,list):
		for i in range(9):
			self.tablecontents += "<tr>"
			for j in range(9):
				name = "f" + str(i) + str(j)
				if(i%3 == 0):
					if(j%3 == 0):
						if(list[i][j] == ''):
							self.adde_entry('g0',name)
						else :
							self.addr_entry('g0',name,list[i][j])
					else :
						if(list[i][j] == ''):
							self.adde_entry('f0',name)
						else :
							self.addr_entry('f0',name,list[i][j])
				elif(i==8) :
					if(j%3 == 0):
						if(list[i][j] == ''):
							self.adde_entry('i0',name)
						else :
							self.addr_entry('i0',name,list[i][j])
					else :
						if(list[i][j] == ''):
							self.adde_entry('h0',name)
						else :
							self.addr_entry('h0',name,list[i][j])
				else :
					if(j%3 == 0):
						if(list[i][j] == ''):
							self.adde_entry('e0',name)
						else :
							self.addr_entry('e0',name,list[i][j])
					else :
						if(list[i][j] == ''):
							self.adde_entry('c0',name)
						else :
							self.addr_entry('c0',name,list[i][j])
			self.tablecontents += "</tr>"
		return;

class HardPage(webapp2.RequestHandler,SudokuGenerator):

	
	tablecontents = '' ;
	hardlist = []; hardsoln = [];
	n=1;	
	genclass = SudokuGenerator();

	def get(self,task=None):
		task = self.request.get('task')
		self.response.headers['Content-Type'] = 'html'
		HardPage.n = int(random()*3) +1;
							
		if(task != 'viewsoln'):

			puzfilename = 'hardpuz'+str(HardPage.n)+'.txt';
			with open(puzfilename, 'r') as content_file1:
				content1 = content_file1.read();
			HardPage.hardlist = ast.literal_eval(content1);
			solnfilename = 'hardsoln'+str(HardPage.n)+'.txt';
			with open(solnfilename, 'r') as content_file2:
				content2 = content_file2.read();
			HardPage.hardsoln = ast.literal_eval(content2);
			
			(HardPage.hardlist,HardPage.hardsoln) = HardPage.genclass.randomize(HardPage.hardlist,HardPage.hardsoln,23)

			self.tablecontents = '' ;
			
			self.list2table(HardPage.hardlist)
			template_values = {
				'tablecontents' : self.tablecontents ,
				
		    }
		
		else:
			self.tablecontents = '' ;		
			
			self.list2table(HardPage.hardsoln)
			template_values = {
				'tablecontents' : self.tablecontents ,
				
		    }

		template = JINJA_ENVIRONMENT.get_template('page.html')
		self.response.write(template.render(template_values))

	def post(self):
		self.response.headers = {'Content-Type': 'application/json; charset=utf-8'}
		self.response.out.write(json.dumps(HardPage.hardsoln))


	#add number as a readonly entry to row
	def addr_entry(self,classname,name,value):
		self.tablecontents += ("<td class='"+classname+"' ><input class='s0' size='2' autocomplete='off'  readonly='' value='"+value+"' name='"+name+"' ></td>")
		return;

	#add blank editable entry to row
	def adde_entry(self,classname,name):
		self.tablecontents += ("<td class='"+classname+"' ><input class='d0' size='2' autocomplete='off'  maxlength='1' name='"+name+"' ></td>")
		return;

	#convert 9x9 list to html content for sudoku table
	def list2table(self,list):
		for i in range(9):
			self.tablecontents += "<tr>"
			for j in range(9):
				name = "f" + str(i) + str(j)
				if(i%3 == 0):
					if(j%3 == 0):
						if(list[i][j] == ''):
							self.adde_entry('g0',name)
						else :
							self.addr_entry('g0',name,list[i][j])
					else :
						if(list[i][j] == ''):
							self.adde_entry('f0',name)
						else :
							self.addr_entry('f0',name,list[i][j])
				elif(i==8) :
					if(j%3 == 0):
						if(list[i][j] == ''):
							self.adde_entry('i0',name)
						else :
							self.addr_entry('i0',name,list[i][j])
					else :
						if(list[i][j] == ''):
							self.adde_entry('h0',name)
						else :
							self.addr_entry('h0',name,list[i][j])
				else :
					if(j%3 == 0):
						if(list[i][j] == ''):
							self.adde_entry('e0',name)
						else :
							self.addr_entry('e0',name,list[i][j])
					else :
						if(list[i][j] == ''):
							self.adde_entry('c0',name)
						else :
							self.addr_entry('c0',name,list[i][j])
			self.tablecontents += "</tr>"
		return;





# --- Main section ---

app = webapp2.WSGIApplication([
    ('/', EasyPage),
    ('/easy', EasyPage),
    ('/medium', MediumPage),
    ('/hard', HardPage),      
], debug=False)

# Extra Hanlder like 404 500 etc
def handle_404(request, response, exception):
	logging.exception(exception)
	response.write('Oops! Page not found (This is a 404)')
	response.set_status(404)

app.error_handlers[404] = handle_404

def main():
    run_wsgi_app(app)

if __name__ == "__main__":
    main()




