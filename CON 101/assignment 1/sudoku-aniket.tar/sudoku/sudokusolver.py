import math;
import ast;

class SudokuSolver:

	# define constants
	N =9;
	UNASSIGNED = 0;



	def checkRow(self,grid,row,column,num):
		l = grid[row]
		
		#print grid;
		if(num not in l):
			return True;
		else :
			return False;

	def checkColumn(self,grid,row,column,num):
		l=[]
		for i in range(len(grid)):
			element = grid[i][column];
			l.append(element);
		
		#print grid;
		if(num not in l):
			return True;
		else :	
			return False;

	def checkBox(self,grid,row,column,num):
		n=int(math.sqrt(len(grid)));
		r=row//n;c=column//n;
		l=[]
		
		for i in range(r*n,(r+1)*n):
			for j in range(c*n,(c+1)*n):
				l.append(grid[i][j]);
		
		#print grid;
		if(num not in l):
			return True;
		else :
			return False;

	def check(self,grid,row,column,num):
		if(self.checkRow(grid,row,column,num) and self.checkColumn(grid,row,column,num) and self.checkBox(grid,row,column,num)) :
			#print grid;
			return True;
		else :
			return False;

	def findUnassigned(self,grid,i,j):
		p=i;q=j;
		for i in range(len(grid)):
			for j in range(len(grid)):
				if grid[i][j]==self.UNASSIGNED :
					return (True,i,j);
		else :
			return (False,p,q);

	def solve(self,grid,i,j):
		
		tup = self.findUnassigned(grid,i,j);
		if(tup[0]==False):
			return True;
		else:
			i=tup[1];j=tup[2];

			
		for num in range(0,10):

			if(self.check(grid,i,j,num)):
				
				grid[i][j] = num;


				if(self.solve(grid,i,j)):
					#print grid
					return True;
				else :
					grid[i][j] = self.UNASSIGNED;

		return False;


with open('hardpuz3.txt', 'r') as content_file:
	content = content_file.read();
list = ast.literal_eval(content);

for i in range(len(list)):
	for j in range(len(list[0])):
		if(list[i][j]==''):
			list[i][j]=0;
		else :
			list[i][j]=int(list[i][j]);


obj = SudokuSolver();
obj.solve(list,0,0);

for i in range(len(list)):
	for j in range(len(list[0])):
		list[i][j] = str(list[i][j]);

print list;





