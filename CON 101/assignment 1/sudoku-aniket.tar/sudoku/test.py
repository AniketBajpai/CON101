from random import random
import numpy as np

	
class SudokuGenerator():

	def rowTransform(self,l1,l2):
		m = int(random()*3);
		n = int(random()*3);
		p = int(random()*3);
		l1[3*p+m], l1[3*p+n] = l1[3*p+n], l1[3*p+m] ;
		l2[3*p+m], l2[3*p+n] = l2[3*p+n], l2[3*p+m] ;
		return (l1,l2) ;


	def columnTransform(self,l1,l2):
		m = int(random()*3);
		n = int(random()*3);
		p = int(random()*3);
		for i in range(9):
			l1[i][3*p+m], l1[i][3*p+n] = l1[i][3*p+n], l1[i][3*p+m] ;
		for i in range(9):
			l2[i][3*p+m], l2[i][3*p+n] = l2[i][3*p+n], l2[i][3*p+m] ;
		return (l1,l2);


	def rotate(self,l1,l2):
		a1 = np.array(l1)
		a1 = np.rot90(a1);
		a2 = np.array(l2)
		a2 = np.rot90(a2);

		return (a1.tolist(),a2.tolist()) ;

	def mirrory(self,l1,l2):
		a1 = np.array(l1)
		a1 = np.fliplr(a1);
		a2 = np.array(l2)
		a2 = np.fliplr(a2);
		return (a1.tolist(),a2.tolist()) ;

	def mirrorx(self,l1,l2):
		a1 = np.array(l1)
		a1 = np.flipud(a1);
		a2 = np.array(l2)
		a2 = np.flipud(a2);
		return (a1.tolist(),a2.tolist()) ;

	def diagonalTransform(self,l1,l2):
		a1 = np.array(l1)
		a1 = np.transpose(a1);
		a2 = np.array(l2)
		a2 = np.transpose(a2);
		return (a1.tolist(),a2.tolist()) ;

	def randomize(self,grid1,grid2,n):
		for i in range(n):
			r = int(random()*6);
			
			if(r == 0):
				(grid1,grid2) = self.rowTransform(grid1,grid2);
				
			elif (r == 1):
				(grid1,grid2) = self.columnTransform(grid1,grid2);

			elif (r == 2):
				(grid1,grid2) = self.rotate(grid1,grid2);

			elif (r == 3):
				(grid1,grid2) = self.mirrorx(grid1,grid2);

			elif (r == 4):
				(grid1,grid2) = self.mirrory(grid1,grid2);

			elif (r == 5):
				(grid1,grid2) = self.diagonalTransform(grid1,grid2);
			
			else :
				pass ;
				

		return (grid1,grid2);

